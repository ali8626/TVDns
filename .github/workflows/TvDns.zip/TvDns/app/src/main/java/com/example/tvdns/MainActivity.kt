package com.example.tvdns

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme

// ---------- الألوان ----------
private val Bg1 = Color(0xFF0B1020)
private val Bg2 = Color(0xFF17235A)
private val CardBg = Color(0xFF1B2444)
private val CardFocus = Color(0xFF2A3870)
private val Accent = Color(0xFF22D3EE)
private val Indigo = Color(0xFF6366F1)
private val Good = Color(0xFF34D399)
private val Warn = Color(0xFFFBBF24)
private val Danger = Color(0xFFF87171)
private val Muted = Color(0xFF94A3B8)

private data class Preset(val name: String, val note: String, val host: String)

private val presets = listOf(
    Preset("AdGuard", "حظر الإعلانات والمتتبعات", "dns.adguard-dns.com"),
    Preset("AdGuard عائلي", "إعلانات + محتوى إباحي", "family.adguard-dns.com"),
    Preset("AdGuard بدون فلترة", "تشفير فقط", "unfiltered.adguard-dns.com"),
    Preset("Cloudflare", "سريع وخصوصية عالية", "one.one.one.one"),
    Preset("Google", "موثوق وسريع", "dns.google"),
    Preset("Quad9", "حماية من النطاقات الخبيثة", "dns.quad9.net"),
    Preset("Mullvad", "خصوصية بدون سجلات", "dns.mullvad.net"),
    Preset("CleanBrowsing عائلي", "حظر المحتوى غير اللائق", "family-filter-dns.cleanbrowsing.org"),
    Preset("DNS for Family", "حظر المحتوى الإباحي", "dns-dot.dnsforfamily.com"),
    Preset("Control D", "حظر الإعلانات (مجاني)", "p2.freedns.controld.com"),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

// ---------- بطاقة قابلة للتركيز بتأثير تكبير وإطار ----------
@Composable
private fun FocusCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    accent: Color = Accent,
    padding: androidx.compose.ui.unit.Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.04f else 1f, label = "scale")
    val shape = RoundedCornerShape(18.dp)
    val borderColor = when {
        focused -> accent
        selected -> Good
        else -> Color.Transparent
    }
    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(if (focused) CardFocus else CardBg)
            .border(if (focused || selected) 2.dp else 0.dp, borderColor, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(padding),
        content = content
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Muted,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun AppRoot() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        androidx.compose.material3.MaterialTheme(
            colorScheme = androidx.compose.material3.darkColorScheme()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.linearGradient(listOf(Bg1, Bg2)))
                    .padding(horizontal = 56.dp, vertical = 32.dp)
            ) {
                val ctx = LocalContext.current
                var granted by remember { mutableStateOf(DnsManager.hasPermission(ctx)) }
                var state by remember { mutableStateOf(DnsManager.read(ctx)) }

                // إعادة الفحص عند الرجوع للتطبيق
                val owner = LocalLifecycleOwner.current
                DisposableEffect(owner) {
                    val obs = LifecycleEventObserver { _, e ->
                        if (e == Lifecycle.Event.ON_RESUME) {
                            granted = DnsManager.hasPermission(ctx)
                            state = DnsManager.read(ctx)
                        }
                    }
                    owner.lifecycle.addObserver(obs)
                    onDispose { owner.lifecycle.removeObserver(obs) }
                }

                if (!granted) {
                    SetupScreen(onRecheck = { granted = DnsManager.hasPermission(ctx) })
                } else {
                    HomeScreen(state = state, onChanged = { state = DnsManager.read(ctx) })
                }
            }
        }
    }
}

// ---------- شاشة الإعداد الأولي ----------
@Composable
private fun StepRow(n: Int, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Indigo),
            contentAlignment = Alignment.Center
        ) { Text("$n", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        Text(text, fontSize = 19.sp, color = Color(0xFFE2E8F0), modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SetupScreen(onRecheck: () -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically)
    ) {
        Text("الإعداد الأولي", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("خطوة واحدة فقط، تُنفَّذ مرة واحدة", fontSize = 18.sp, color = Muted)
        StepRow(1, "الإعدادات ← حول ← اضغط على «إصدار البناء» 7 مرات لتفعيل خيارات المطور.")
        StepRow(2, "خيارات المطور ← فعّل «تصحيح USB» أو «التصحيح اللاسلكي».")
        StepRow(3, "من الكمبيوتر أو الهاتف (Termux) نفّذ adb connect ثم الأمر التالي:")
        Text(
            "adb shell pm grant com.example.tvdns android.permission.WRITE_SECURE_SETTINGS",
            fontFamily = FontFamily.Monospace, fontSize = 17.sp, color = Accent,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0F172A))
                .padding(18.dp)
        )
        StepRow(4, "ارجع هنا واضغط الزر.")
        FocusCard(onClick = onRecheck, modifier = Modifier.focusRequester(focus).width(260.dp)) {
            Text("تحقق مرة أخرى", fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth())
        }
    }
}

// ---------- الشاشة الرئيسية ----------
@Composable
private fun StatusPanel(
    state: DnsState,
    focus: FocusRequester,
    onToggle: () -> Unit,
    onAuto: () -> Unit
) {
    val active = state.isHostname
    val statusText = when {
        active -> "الحماية مفعّلة"
        state.mode == "off" -> "متوقف"
        else -> "تلقائي"
    }
    val statusColor = if (active) Good else Warn

    Column(
        Modifier.width(340.dp).fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Indigo, Accent))),
            contentAlignment = Alignment.Center
        ) { Text("DNS", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }

        Text("Private DNS", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)

        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(statusColor))
            Text(statusText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = statusColor)
        }

        Text(
            if (active) state.host.orEmpty() else "لا يوجد خادم نشط",
            fontSize = 17.sp, color = Muted, fontFamily = FontFamily.Monospace
        )

        Spacer(Modifier.height(10.dp))

        FocusCard(
            onClick = onToggle,
            modifier = Modifier.focusRequester(focus).fillMaxWidth(),
            accent = if (active) Danger else Good
        ) {
            Text(
                if (active) "إيقاف الحماية" else "تفعيل الحماية",
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                color = if (active) Danger else Good,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
        FocusCard(onClick = onAuto, modifier = Modifier.fillMaxWidth(), padding = 12.dp) {
            Text("الوضع التلقائي", fontSize = 18.sp, color = Color.White,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun HomeScreen(state: DnsState, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var custom by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(Store.load(ctx)) }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    fun apply(host: String) {
        DnsManager.setHostname(ctx, host)
        Store.setLast(ctx, host)
        error = null
        onChanged()
    }

    fun isCurrent(host: String) = state.isHostname && state.host == host

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(44.dp)) {
        StatusPanel(
            state = state,
            focus = firstFocus,
            onToggle = {
                if (state.isHostname) DnsManager.turnOff(ctx)
                else apply(Store.last(ctx) ?: presets.first().host)
                onChanged()
            },
            onAuto = { DnsManager.setAutomatic(ctx); onChanged() }
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 6.dp)
        ) {
            if (saved.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle("خوادمك المحفوظة") }
                items(saved, span = { GridItemSpan(maxLineSpan) }) { host ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FocusCard(
                            onClick = { apply(host) },
                            modifier = Modifier.weight(1f),
                            selected = isCurrent(host)
                        ) {
                            Text(host, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                color = Color.White, fontFamily = FontFamily.Monospace)
                            if (isCurrent(host)) Text("مفعّل الآن", fontSize = 14.sp, color = Good)
                        }
                        FocusCard(
                            onClick = { saved = Store.remove(ctx, host) },
                            accent = Danger, padding = 14.dp
                        ) { Text("حذف", fontSize = 16.sp, color = Danger) }
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle("خوادم جاهزة") }
            items(presets) { p ->
                val current = isCurrent(p.host)
                FocusCard(
                    onClick = { apply(p.host) },
                    modifier = Modifier.fillMaxWidth(),
                    selected = current
                ) {
                    Text(p.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(p.note, fontSize = 15.sp, color = Muted)
                    Text(
                        if (current) "مفعّل الآن" else p.host,
                        fontSize = 13.sp,
                        color = if (current) Good else Accent,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("إضافة خادم مخصص")
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = custom,
                            onValueChange = { custom = it },
                            label = { androidx.compose.material3.Text("مثال: abc123.dns.nextdns.io") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        FocusCard(
                            onClick = {
                                val h = custom.trim().lowercase()
                                if (DnsManager.isValidHost(h)) {
                                    saved = Store.add(ctx, h)
                                    apply(h)
                                    custom = ""
                                } else error = "اسم الخادم غير صالح"
                            }
                        ) { Text("حفظ وتفعيل", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White) }
                    }
                    error?.let { Text(it, color = Danger, fontSize = 16.sp) }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}
