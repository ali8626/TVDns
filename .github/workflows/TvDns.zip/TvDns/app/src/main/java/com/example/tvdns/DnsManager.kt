package com.example.tvdns

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

data class DnsState(val mode: String?, val host: String?) {
    val isHostname get() = mode == "hostname" && !host.isNullOrBlank()
}

object DnsManager {
    private const val KEY_MODE = "private_dns_mode"
    private const val KEY_HOST = "private_dns_specifier"

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    fun read(ctx: Context): DnsState {
        val r = ctx.contentResolver
        return DnsState(
            mode = Settings.Global.getString(r, KEY_MODE),
            host = Settings.Global.getString(r, KEY_HOST)
        )
    }

    /** تفعيل الخادم المحدد (Strict / hostname). */
    fun setHostname(ctx: Context, host: String): Boolean = runCatching {
        val r = ctx.contentResolver
        Settings.Global.putString(r, KEY_HOST, host)   // الخادم أولاً ثم الوضع
        Settings.Global.putString(r, KEY_MODE, "hostname")
    }.getOrDefault(false)

    /** تلقائي: يستخدم DNS-over-TLS إن دعمه الخادم الحالي. */
    fun setAutomatic(ctx: Context): Boolean = runCatching {
        Settings.Global.putString(ctx.contentResolver, KEY_MODE, "opportunistic")
    }.getOrDefault(false)

    fun turnOff(ctx: Context): Boolean = runCatching {
        Settings.Global.putString(ctx.contentResolver, KEY_MODE, "off")
    }.getOrDefault(false)

    private val hostRegex =
        Regex("^(?=.{1,253}$)([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,}$")

    fun isValidHost(h: String) = hostRegex.matches(h.trim())
}
