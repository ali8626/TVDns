package com.example.tvdns

import android.content.Context

/** حفظ الخوادم المخصصة محلياً. */
object Store {
    private const val PREFS = "tvdns"
    private const val KEY = "custom_hosts"

    fun load(ctx: Context): List<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "")!!
            .split("\n")
            .filter { it.isNotBlank() }

    private fun save(ctx: Context, list: List<String>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, list.joinToString("\n")).apply()
    }

    fun add(ctx: Context, host: String): List<String> {
        val list = (listOf(host) + load(ctx)).distinct().take(10)
        save(ctx, list)
        return list
    }

    fun remove(ctx: Context, host: String): List<String> {
        val list = load(ctx) - host
        save(ctx, list)
        return list
    }

    private const val KEY_LAST = "last_host"

    fun last(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LAST, null)

    fun setLast(ctx: Context, host: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LAST, host).apply()
    }
}
