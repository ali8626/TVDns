# TvDns — Private DNS لـ Google TV

## التشغيل
1. افتح المجلد في Android Studio (Koala أو أحدث) ودعه يزامن Gradle (سينشئ gradle wrapper تلقائياً).
2. ابنِ ثم ثبّت على التلفاز: `adb connect IP:5555` ثم Run، أو `adb install app-debug.apk`.
3. امنح الصلاحية مرة واحدة:
   adb shell pm grant com.example.tvdns android.permission.WRITE_SECURE_SETTINGS
4. افتح التطبيق من الشاشة الرئيسية واختر الخادم.

## ملاحظات
- يتطلب Android 9+ (API 28).
- للإلغاء: اضغط «إيقاف» أو «تلقائي».
- بعض أجهزة Google TV تتجاهل الإعداد إن كان الجهاز مقيّداً من الشركة المصنعة؛ جرّب `adb shell settings get global private_dns_mode` للتحقق.
