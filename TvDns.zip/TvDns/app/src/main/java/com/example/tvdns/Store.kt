package com.example.tvdns

import android.content.Context

data class CustomServer(val name: String, val note: String, val host: String)

object Store {
    private const val PREFS = "tvdns"
    private const val KEY = "custom_hosts"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun clean(s: String) = s.replace("\t", " ").replace("\n", " ").trim()

    /** الخوادم المخصصة (الاسم، الوصف، الرابط). يدعم الصيغة القديمة (رابط فقط). */
    fun load(ctx: Context): List<CustomServer> =
        prefs(ctx).getString(KEY, "")!!
            .split("\n")
            .filter { it.isNotBlank() }
            .map { line ->
                val parts = line.split("\t")
                if (parts.size >= 3) CustomServer(parts[0], parts[1], parts[2])
                else CustomServer(parts[0], "", parts[0])
            }

    private fun save(ctx: Context, list: List<CustomServer>) {
        prefs(ctx).edit().putString(
            KEY,
            list.joinToString("\n") { "${clean(it.name)}\t${clean(it.note)}\t${it.host}" }
        ).apply()
    }

    fun add(ctx: Context, s: CustomServer): List<CustomServer> {
        val list = (listOf(s) + load(ctx).filter { it.host != s.host }).take(20)
        save(ctx, list)
        return list
    }

    fun remove(ctx: Context, host: String): List<CustomServer> {
        val list = load(ctx).filter { it.host != host }
        save(ctx, list)
        return list
    }

    fun last(ctx: Context): String? = prefs(ctx).getString("last_host", null)
    fun setLast(ctx: Context, host: String) { prefs(ctx).edit().putString("last_host", host).apply() }

    fun lang(ctx: Context): String = prefs(ctx).getString("lang", "ar") ?: "ar"
    fun setLang(ctx: Context, v: String) { prefs(ctx).edit().putString("lang", v).apply() }

    fun theme(ctx: Context): String = prefs(ctx).getString("theme", "dark") ?: "dark"
    fun setTheme(ctx: Context, v: String) { prefs(ctx).edit().putString("theme", v).apply() }
}
