package com.example.tvdns

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import java.net.Inet4Address
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import androidx.tv.material3.lightColorScheme

// ---------- الألوان (داكن / فاتح) ----------
private data class Palette(
    val bg1: Color, val bg2: Color, val card: Color, val cardFocus: Color,
    val text: Color, val muted: Color, val accent: Color, val indigo: Color,
    val good: Color, val warn: Color, val danger: Color, val codeBg: Color, val codeText: Color
)

private val DarkPalette = Palette(
    bg1 = Color(0xFF0B1020), bg2 = Color(0xFF17235A),
    card = Color(0xFF1B2444), cardFocus = Color(0xFF2A3870),
    text = Color.White, muted = Color(0xFF94A3B8),
    accent = Color(0xFF22D3EE), indigo = Color(0xFF6366F1),
    good = Color(0xFF34D399), warn = Color(0xFFFBBF24), danger = Color(0xFFF87171),
    codeBg = Color(0xFF0F172A), codeText = Color(0xFF22D3EE)
)

private val LightPalette = Palette(
    bg1 = Color(0xFFF1F5F9), bg2 = Color(0xFFDDE5FF),
    card = Color.White, cardFocus = Color(0xFFDBEAFE),
    text = Color(0xFF0F172A), muted = Color(0xFF64748B),
    accent = Color(0xFF0891B2), indigo = Color(0xFF6366F1),
    good = Color(0xFF059669), warn = Color(0xFFB45309), danger = Color(0xFFDC2626),
    codeBg = Color(0xFFE2E8F0), codeText = Color(0xFF0E7490)
)

private val LocalPalette = compositionLocalOf { DarkPalette }
private val LocalLang = compositionLocalOf { "ar" }

@Composable
private fun tr(ar: String, en: String): String = if (LocalLang.current == "ar") ar else en

// ---------- الخوادم الجاهزة ----------
private data class Preset(
    val nameAr: String, val nameEn: String,
    val noteAr: String, val noteEn: String,
    val host: String
)

private val presets = listOf(
    Preset("AdGuard", "AdGuard", "حظر الإعلانات والمتتبعات", "Blocks ads & trackers", "dns.adguard-dns.com"),
    Preset("AdGuard عائلي", "AdGuard Family", "إعلانات + محتوى إباحي", "Ads + adult content", "family.adguard-dns.com"),
    Preset("AdGuard بدون فلترة", "AdGuard Unfiltered", "تشفير فقط", "Encryption only", "unfiltered.adguard-dns.com"),
    Preset("Cloudflare", "Cloudflare", "سريع وخصوصية عالية", "Fast and private", "one.one.one.one"),
    Preset("Cloudflare أمان", "Cloudflare Security", "حظر البرمجيات الخبيثة", "Blocks malware", "security.cloudflare-dns.com"),
    Preset("Cloudflare عائلي", "Cloudflare Family", "برمجيات خبيثة + محتوى إباحي", "Malware + adult content", "family.cloudflare-dns.com"),
    Preset("Google", "Google", "موثوق وسريع", "Reliable and fast", "dns.google"),
    Preset("Quad9", "Quad9", "حماية من النطاقات الخبيثة", "Blocks malicious domains", "dns.quad9.net"),
    Preset("CleanBrowsing عائلي", "CleanBrowsing Family", "حظر المحتوى غير اللائق", "Blocks inappropriate content", "family-filter-dns.cleanbrowsing.org"),
    Preset("DNS for Family", "DNS for Family", "حظر المحتوى الإباحي", "Blocks adult content", "dns-dot.dnsforfamily.com"),
    Preset("Control D", "Control D", "حظر الإعلانات (مجاني)", "Ad blocking (free)", "p2.freedns.controld.com"),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

// ---------- بطاقة قابلة للتركيز ----------
@Composable
private fun FocusCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    accent: Color? = null,
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.04f else 1f, label = "scale")
    val shape = RoundedCornerShape(18.dp)
    val borderColor = when {
        focused -> accent ?: p.accent
        selected -> p.good
        else -> Color.Transparent
    }
    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(if (focused) p.cardFocus else p.card)
            .border(if (focused || selected) 2.dp else 0.dp, borderColor, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(padding),
        content = content
    )
}

@Composable
private fun SectionTitle(text: String) {
    val p = LocalPalette.current
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = p.muted,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Store.lang(ctx)) }
    var theme by remember { mutableStateOf(Store.theme(ctx)) }
    var screen by remember { mutableStateOf("home") }   // home / settings / servers

    val dark = theme == "dark"
    val p = if (dark) DarkPalette else LightPalette
    val tvScheme = if (dark) darkColorScheme() else lightColorScheme()
    val m3Scheme = if (dark) androidx.compose.material3.darkColorScheme()
    else androidx.compose.material3.lightColorScheme()

    CompositionLocalProvider(
        LocalPalette provides p,
        LocalLang provides lang,
        LocalLayoutDirection provides (if (lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        MaterialTheme(colorScheme = tvScheme) {
            androidx.compose.material3.MaterialTheme(colorScheme = m3Scheme) {
                BackHandler(enabled = screen != "home") {
                    screen = if (screen == "servers" || screen == "guide") "settings" else "home"
                }

                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.linearGradient(listOf(p.bg1, p.bg2)))
                        .padding(horizontal = 56.dp, vertical = 32.dp)
                ) {
                    var granted by remember { mutableStateOf(DnsManager.hasPermission(ctx)) }
                    var state by remember { mutableStateOf(DnsManager.read(ctx)) }

                    val owner = LocalLifecycleOwner.current
                    DisposableEffect(owner) {
                        val obs = LifecycleEventObserver { _, e ->
                            if (e == Lifecycle.Event.ON_RESUME) {
                                granted = DnsManager.hasPermission(ctx)
                                state = DnsManager.read(ctx)
                            }
                        }
                        owner.lifecycle.addObserver(obs)
                        onDispose { owner.lifecycle.removeObserver(obs) }
                    }

                    when {
                        screen == "guide" -> SetupScreen(
                            onRecheck = { granted = DnsManager.hasPermission(ctx); screen = "home" },
                            onSettings = { screen = "settings" }
                        )
                        screen == "servers" -> ServersScreen(onBack = { screen = "settings" })
                        screen == "settings" -> SettingsScreen(
                            lang = lang, theme = theme,
                            onLang = { lang = it; Store.setLang(ctx, it) },
                            onTheme = { theme = it; Store.setTheme(ctx, it) },
                            onServers = { screen = "servers" },
                            onGuide = { screen = "guide" },
                            onBack = { screen = "home" }
                        )
                        !granted -> SetupScreen(
                            onRecheck = { granted = DnsManager.hasPermission(ctx) },
                            onSettings = { screen = "settings" }
                        )
                        else -> HomeScreen(
                            state = state,
                            onChanged = { state = DnsManager.read(ctx) },
                            onSettings = { screen = "settings" }
                        )
                    }
                }
            }
        }
    }
}

// ---------- شاشة الإعدادات ----------
@Composable
private fun OptionCard(label: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    FocusCard(onClick = onClick, modifier = Modifier.width(230.dp), selected = selected) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = p.text,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        if (selected) {
            Text(tr("مفعّل", "Active"), fontSize = 14.sp, color = p.good,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SettingsScreen(
    lang: String, theme: String,
    onLang: (String) -> Unit, onTheme: (String) -> Unit,
    onServers: () -> Unit, onGuide: () -> Unit, onBack: () -> Unit
) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                FocusCard(onClick = onBack, modifier = Modifier.focusRequester(focus), padding = 12.dp) {
                    Text(tr("رجوع", "Back"), fontSize = 18.sp, color = p.text)
                }
                Text(tr("الإعدادات", "Settings"), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = p.text)
            }
        }
        item { SectionTitle(tr("اللغة", "Language")) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                OptionCard("العربية", lang == "ar") { onLang("ar") }
                OptionCard("English", lang == "en") { onLang("en") }
            }
        }
        item { SectionTitle(tr("المظهر", "Theme")) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                OptionCard(tr("داكن", "Dark"), theme == "dark") { onTheme("dark") }
                OptionCard(tr("فاتح", "Light"), theme == "light") { onTheme("light") }
            }
        }
        item { SectionTitle(tr("الخوادم", "Servers")) }
        item {
            FocusCard(onClick = onServers, modifier = Modifier.width(480.dp)) {
                Text(tr("إضافة وإدارة الخوادم المخصصة", "Add & manage custom servers"),
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = p.text,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        item { SectionTitle(tr("الصلاحية", "Permission")) }
        item {
            FocusCard(onClick = onGuide, modifier = Modifier.width(480.dp)) {
                Text(tr("دليل تفعيل الصلاحية خطوة بخطوة", "Step-by-step permission guide"),
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = p.text,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        item { SectionTitle(tr("حول", "About")) }
        item { Text("Private DNS 1.7", fontSize = 18.sp, color = p.muted) }
    }
}

// ---------- شاشة إضافة وإدارة الخوادم المخصصة ----------
@Composable
private fun ServersScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var name by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(Store.load(ctx)) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val invalidMsg = tr("رابط السيرفر غير صالح", "Invalid server URL")
    val savedMsg = tr("تم حفظ السيرفر، وسيظهر في الشاشة الرئيسية", "Server saved. It now appears on the home screen")

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                FocusCard(onClick = onBack, modifier = Modifier.focusRequester(focus), padding = 12.dp) {
                    Text(tr("رجوع", "Back"), fontSize = 18.sp, color = p.text)
                }
                Text(tr("الخوادم المخصصة", "Custom servers"), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = p.text)
            }
        }
        item { SectionTitle(tr("إضافة سيرفر", "Add a server")) }
        item {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { androidx.compose.material3.Text(tr("اسم السيرفر", "Server name")) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { androidx.compose.material3.Text(tr("وصف السيرفر", "Server description")) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { androidx.compose.material3.Text(tr("رابط السيرفر (URL)", "Server URL")) },
                placeholder = { androidx.compose.material3.Text("abc123.dns.nextdns.io") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusCard(
                    onClick = {
                        val host = DnsManager.normalizeHost(url)
                        if (DnsManager.isValidHost(host)) {
                            Store.add(ctx, CustomServer(name.trim().ifBlank { host }, note.trim(), host))
                            saved = Store.load(ctx)
                            name = ""; note = ""; url = ""
                            isError = false; message = savedMsg
                        } else {
                            isError = true; message = invalidMsg
                        }
                    },
                    modifier = Modifier.width(220.dp)
                ) {
                    Text(tr("حفظ", "Save"), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = p.good, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                }
                message?.let {
                    Text(it, fontSize = 16.sp, color = if (isError) p.danger else p.good,
                        modifier = Modifier.weight(1f))
                }
            }
        }

        item { SectionTitle(tr("الخوادم المحفوظة", "Saved servers")) }
        if (saved.isEmpty()) {
            item { Text(tr("لا توجد خوادم محفوظة بعد", "No saved servers yet"),
                fontSize = 16.sp, color = p.muted) }
        }
        items(saved) { s ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FocusCard(onClick = {}, modifier = Modifier.weight(1f)) {
                    Text(s.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = p.text)
                    if (s.note.isNotBlank()) Text(s.note, fontSize = 15.sp, color = p.muted)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(s.host, fontSize = 14.sp, color = p.accent,
                            fontFamily = FontFamily.Monospace, maxLines = 1)
                    }
                }
                FocusCard(
                    onClick = { saved = Store.remove(ctx, s.host) },
                    accent = p.danger, padding = 14.dp
                ) { Text(tr("حذف", "Delete"), fontSize = 16.sp, color = p.danger) }
            }
        }
    }
}

// ---------- دليل تفعيل الصلاحية ----------
@Composable
private fun StepRow(n: Int, text: String) {
    val p = LocalPalette.current
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(p.indigo),
            contentAlignment = Alignment.Center
        ) { Text("$n", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        Text(text, fontSize = 19.sp, color = p.text, modifier = Modifier.weight(1f))
    }
}

private fun openSettings(ctx: Context, action: String): Boolean = try {
    ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

private fun localIp(ctx: Context): String? = runCatching {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val net = cm.activeNetwork ?: return@runCatching null
    val lp = cm.getLinkProperties(net) ?: return@runCatching null
    lp.linkAddresses.map { it.address }
        .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
}.getOrNull()

@Composable
private fun QrCode(text: String, size: Dp) {
    val matrix = remember(text) {
        runCatching {
            QRCodeWriter().encode(
                text, BarcodeFormat.QR_CODE, 0, 0,
                mapOf(
                    EncodeHintType.MARGIN to 0,
                    EncodeHintType.CHARACTER_SET to "UTF-8",
                    EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M
                )
            )
        }.getOrNull()
    }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .padding(12.dp)
    ) {
        if (matrix != null) {
            Canvas(Modifier.fillMaxSize()) {
                val n = matrix.width
                val cell = this.size.minDimension / n
                for (y in 0 until n) {
                    for (x in 0 until n) {
                        if (matrix.get(x, y)) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset(x * cell, y * cell),
                                size = Size(cell + 0.5f, cell + 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    FocusCard(onClick = onClick, modifier = modifier.width(320.dp), padding = 12.dp) {
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = p.accent,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun SetupScreen(onRecheck: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    var msg by remember { mutableStateOf<String?>(null) }
    val ip = remember { localIp(ctx) }
    val ipShown = ip ?: "TV_IP"
    val failMsg = tr(
        "تعذّر فتح هذه الشاشة من التطبيق، افتحها يدوياً من إعدادات التلفاز",
        "Couldn't open that screen from the app; open it manually from the TV settings"
    )
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text(tr("دليل تفعيل الصلاحية", "Permission setup guide"), fontSize = 34.sp,
                fontWeight = FontWeight.Bold, color = p.text)
            Text(tr("تُنفَّذ الخطوات مرة واحدة فقط، وبعدها لن تحتاجها",
                "Do this once only; you won't need it again"),
                fontSize = 17.sp, color = p.muted)
        }

        // 1) خيارات المطور
        item { SectionTitle(tr("1. تفعيل خيارات المطور", "1. Enable Developer options")) }
        item {
            StepRow(1, tr(
                "افتح الإعدادات ← حول ← اضغط 7 مرات على «إصدار البناء» (Build) حتى تظهر رسالة أنك أصبحت مطوراً.",
                "Open Settings → About → press “Build” 7 times until a message says you are now a developer."))
        }
        item {
            GuideButton(tr("فتح «حول الجهاز»", "Open “About device”"), Modifier.focusRequester(focus)) {
                if (!openSettings(ctx, Settings.ACTION_DEVICE_INFO_SETTINGS)) msg = failMsg
            }
        }

        // 2) التصحيح
        item { SectionTitle(tr("2. تفعيل التصحيح", "2. Enable debugging")) }
        item {
            StepRow(2, tr(
                "افتح خيارات المطور ← فعّل «تصحيح USB».",
                "Open Developer options → turn on “USB debugging”."))
        }
        item {
            StepRow(3, tr(
                "فعّل «التصحيح اللاسلكي» (Wireless debugging)، ثم اختر «إقران الجهاز برمز الاقتران». اترك تلك الشاشة مفتوحة، فيظهر فيها رمز من 6 أرقام وعنوان الاقتران مع منفذه.",
                "Turn on “Wireless debugging”, then choose “Pair device with pairing code”. Keep that screen open: it shows a 6-digit code and the pairing address with its port."))
        }
        item {
            GuideButton(tr("فتح «خيارات المطور»", "Open “Developer options”")) {
                if (!openSettings(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) msg = failMsg
            }
        }

        // 3) الأوامر
        item { SectionTitle(tr("3. من الهاتف (Termux) أو الكمبيوتر", "3. From your phone (Termux) or computer")) }
        if (ip != null) {
            item {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(tr("عنوان تلفازك: $ip", "Your TV address: $ip"),
                        fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = p.good,
                        fontFamily = FontFamily.Monospace)
                }
            }
        }
        item {
            val cmds = "adb pair $ipShown:PAIR_PORT\n" +
                "adb connect $ipShown:PORT\n" +
                "adb shell pm grant com.example.tvdns android.permission.WRITE_SECURE_SETTINGS"
            Row(
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(Modifier.weight(1f)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            cmds,
                            fontFamily = FontFamily.Monospace, fontSize = 16.sp, color = p.codeText,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(p.codeBg)
                                .padding(16.dp)
                        )
                    }
                }
                Column(
                    Modifier.width(210.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QrCode(cmds, 200.dp)
                    Text(
                        tr("امسح الرمز بكاميرا هاتفك لنسخ الأوامر ثم الصقها في Termux",
                            "Scan with your phone camera to copy the commands, then paste them into Termux"),
                        fontSize = 14.sp, color = p.muted, textAlign = TextAlign.Center
                    )
                }
            }
        }
        item {
            StepRow(4, tr(
                "PAIR_PORT هو منفذ الاقتران الظاهر في شاشة الرمز، ويُكتب الرمز عند الطلب.",
                "PAIR_PORT is the pairing port shown on the code screen; type the code when asked."))
        }
        item {
            StepRow(5, tr(
                "PORT هو منفذ الاتصال الظاهر في الشاشة الرئيسية لـ Wireless debugging (غير منفذ الاقتران، ويتغير كل مرة).",
                "PORT is the connection port shown on the main Wireless debugging screen (different from the pairing port, and it changes each time)."))
        }
        item {
            StepRow(6, tr(
                "بعد آخر أمر لا تظهر رسالة، وهذا يعني النجاح. ارجع هنا واضغط «تحقق مرة أخرى».",
                "No message after the last command means success. Come back here and press “Check again”."))
        }

        // 4) نصائح
        item { SectionTitle(tr("نصائح", "Tips")) }
        item {
            Text(
                tr(
                    "• إن ظهر «more than one device» فنفّذ adb disconnect ثم اتصل من جديد.\n" +
                        "• إن لم تظهر نافذة التفويض على التلفاز فأعد تشغيله بعد تفعيل التصحيح.\n" +
                        "• حذف التطبيق يسحب الصلاحية، فحدّثه دائماً فوق النسخة الحالية.",
                    "• If you see “more than one device”, run adb disconnect and connect again.\n" +
                        "• If the authorization prompt doesn't appear, restart the TV after enabling debugging.\n" +
                        "• Uninstalling the app removes the permission, so always update over the existing version."
                ),
                fontSize = 17.sp, color = p.muted
            )
        }

        msg?.let { item { Text(it, fontSize = 16.sp, color = p.danger) } }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                FocusCard(onClick = onRecheck, modifier = Modifier.width(240.dp)) {
                    Text(tr("تحقق مرة أخرى", "Check again"), fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold, color = p.text,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                FocusCard(onClick = onSettings, modifier = Modifier.width(200.dp)) {
                    Text(tr("الإعدادات", "Settings"), fontSize = 20.sp, color = p.text,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

// ---------- الشاشة الرئيسية ----------
@Composable
private fun StatusPanel(
    state: DnsState,
    focus: FocusRequester,
    onToggle: () -> Unit,
    onSettings: () -> Unit
) {
    val p = LocalPalette.current
    val active = state.isHostname
    val statusText = when {
        active -> tr("الحماية مفعّلة", "Protection on")
        state.mode == "off" -> tr("متوقف", "Off")
        else -> tr("تلقائي", "Automatic")
    }
    val statusColor = if (active) p.good else p.warn

    Column(
        Modifier.width(340.dp).fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(p.indigo, Color(0xFF22D3EE)))),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(R.drawable.ic_server),
                contentDescription = null,
                modifier = Modifier.size(54.dp)
            )
        }

        Text("Private DNS", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = p.text)

        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(statusColor))
            Text(statusText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = statusColor)
        }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                if (active) state.host.orEmpty() else tr("لا يوجد خادم نشط", "No active server"),
                fontSize = 17.sp, color = p.muted, fontFamily = FontFamily.Monospace
            )
        }

        Spacer(Modifier.height(8.dp))

        FocusCard(
            onClick = onToggle,
            modifier = Modifier.focusRequester(focus).fillMaxWidth(),
            accent = if (active) p.danger else p.good
        ) {
            Text(
                if (active) tr("إيقاف الحماية", "Turn off") else tr("تفعيل الحماية", "Turn on"),
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                color = if (active) p.danger else p.good,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
        FocusCard(onClick = onSettings, modifier = Modifier.fillMaxWidth(), padding = 12.dp) {
            Text(tr("الإعدادات", "Settings"), fontSize = 18.sp, color = p.text,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun HomeScreen(state: DnsState, onChanged: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val saved = remember { Store.load(ctx) }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    fun apply(host: String) {
        DnsManager.setHostname(ctx, host)
        Store.setLast(ctx, host)
        onChanged()
    }

    fun isCurrent(host: String) = state.isHostname && state.host == host

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(44.dp)) {
        StatusPanel(
            state = state,
            focus = firstFocus,
            onToggle = {
                if (state.isHostname) DnsManager.turnOff(ctx)
                else apply(Store.last(ctx) ?: presets.first().host)
                onChanged()
            },
            onSettings = onSettings
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 6.dp)
        ) {
            if (saved.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    SectionTitle(tr("خوادمك", "Your servers"))
                }
                items(saved) { s ->
                    val current = isCurrent(s.host)
                    FocusCard(
                        onClick = { apply(s.host) },
                        modifier = Modifier.fillMaxWidth(),
                        selected = current
                    ) {
                        Text(s.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = p.text)
                        if (s.note.isNotBlank()) Text(s.note, fontSize = 15.sp, color = p.muted)
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                if (current) tr("مفعّل الآن", "Active now") else s.host,
                                fontSize = 13.sp,
                                color = if (current) p.good else p.accent,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle(tr("خوادم جاهزة", "Ready-made servers"))
            }
            items(presets) { pr ->
                val current = isCurrent(pr.host)
                FocusCard(
                    onClick = { apply(pr.host) },
                    modifier = Modifier.fillMaxWidth(),
                    selected = current
                ) {
                    Text(tr(pr.nameAr, pr.nameEn), fontSize = 20.sp,
                        fontWeight = FontWeight.Bold, color = p.text)
                    Text(tr(pr.noteAr, pr.noteEn), fontSize = 15.sp, color = p.muted)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            if (current) tr("مفعّل الآن", "Active now") else pr.host,
                            fontSize = 13.sp,
                            color = if (current) p.good else p.accent,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(24.dp)) }
        }
    }
}
