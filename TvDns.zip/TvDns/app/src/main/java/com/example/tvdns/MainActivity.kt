package com.example.tvdns

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.runtime.DisposableEffect
import androidx.tv.material3.Button
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme

private data class Preset(val name: String, val note: String, val host: String)

private val presets = listOf(
    Preset("AdGuard", "حظر الإعلانات والمتتبعات", "dns.adguard-dns.com"),
    Preset("Cloudflare", "سريع وخصوصية عالية", "one.one.one.one"),
    Preset("Google", "dns.google", "dns.google"),
    Preset("Quad9", "حماية من النطاقات الخبيثة", "dns.quad9.net"),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun AppRoot() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        androidx.compose.material3.MaterialTheme(
            colorScheme = androidx.compose.material3.darkColorScheme()
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 64.dp, vertical = 32.dp)
            ) {
                val ctx = LocalContext.current
                var granted by remember { mutableStateOf(DnsManager.hasPermission(ctx)) }
                var state by remember { mutableStateOf(DnsManager.read(ctx)) }

                // إعادة الفحص عند الرجوع للتطبيق (بعد تنفيذ أمر ADB مثلاً)
                val owner = LocalLifecycleOwner.current
                DisposableEffect(owner) {
                    val obs = LifecycleEventObserver { _, e ->
                        if (e == Lifecycle.Event.ON_RESUME) {
                            granted = DnsManager.hasPermission(ctx)
                            state = DnsManager.read(ctx)
                        }
                    }
                    owner.lifecycle.addObserver(obs)
                    onDispose { owner.lifecycle.removeObserver(obs) }
                }

                if (!granted) {
                    SetupScreen(onRecheck = { granted = DnsManager.hasPermission(ctx) })
                } else {
                    HomeScreen(state = state, onChanged = { state = DnsManager.read(ctx) })
                }
            }
        }
    }
}

@Composable
private fun SetupScreen(onRecheck: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("الإعداد الأولي (مرة واحدة)", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(
            "1) الإعدادات ← حول ← اضغط على «إصدار البناء» 7 مرات لتفعيل خيارات المطور.\n" +
                "2) خيارات المطور ← فعّل «تصحيح USB» أو «التصحيح اللاسلكي».\n" +
                "3) من الكمبيوتر (بعد adb connect IP_التلفاز) نفّذ الأمر التالي:",
            fontSize = 18.sp, color = Color(0xFFCBD5E1)
        )
        Text(
            "adb shell pm grant com.example.tvdns android.permission.WRITE_SECURE_SETTINGS",
            fontFamily = FontFamily.Monospace, fontSize = 17.sp, color = Color(0xFF38BDF8),
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E293B))
                .padding(16.dp)
        )
        Text("4) ارجع هنا واضغط الزر.", fontSize = 18.sp, color = Color(0xFFCBD5E1))
        Button(onClick = onRecheck) { Text("تحقق مرة أخرى") }
    }
}

@Composable
private fun HomeScreen(state: DnsState, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var custom by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val statusText = when {
        state.isHostname -> "مفعّل: ${state.host}"
        state.mode == "off" -> "متوقف"
        else -> "تلقائي"
    }
    val statusColor = if (state.isHostname) Color(0xFF4ADE80) else Color(0xFFFBBF24)

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Private DNS", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("الحالة: $statusText", fontSize = 22.sp, color = statusColor,
                modifier = Modifier.padding(top = 4.dp))
        }
        items(presets) { p ->
            Button(
                onClick = { DnsManager.setHostname(ctx, p.host); error = null; onChanged() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(p.name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(p.note, fontSize = 15.sp)
                }
            }
        }
        item {
            OutlinedTextField(
                value = custom,
                onValueChange = { custom = it },
                label = { androidx.compose.material3.Text("خادم مخصص (مثال: abc123.dns.nextdns.io)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            error?.let { Text(it, color = Color(0xFFF87171), fontSize = 16.sp) }
        }
        item {
            Button(
                onClick = {
                    val h = custom.trim()
                    if (DnsManager.isValidHost(h)) {
                        DnsManager.setHostname(ctx, h); error = null; onChanged()
                    } else error = "اسم الخادم غير صالح"
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تفعيل الخادم المخصص") }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { DnsManager.setAutomatic(ctx); onChanged() }) { Text("تلقائي") }
                Button(onClick = { DnsManager.turnOff(ctx); onChanged() }) { Text("إيقاف") }
            }
        }
    }
}
